# Assignment 3
Assignment no. 3, for ITAcademy
When run, this example does not produce expected result. Please, find out the problem with this source code.
